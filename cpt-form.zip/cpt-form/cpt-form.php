<?php
/*
Plugin Name: CPT Form
Plugin URI: http://example.com
Description: This plugin inputs Name and URL from user and then stores it into custom post type (Website) . Source code of URL is fetched and displayed in custom Metabox. While all other Metaboxes are disabled in this plugin.
Version: 11.0
Author: Ahsan Nawaz Bhatti
*/
   
    // fetching Source code 
    function fetch_code($domain ) {

    	$ch = curl_init();
    	curl_setopt($ch, CURLOPT_URL, $domain);
    	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    	curl_setopt($ch,CURLOPT_USERAGENT,'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0.0.13');
    	$content = curl_exec($ch);
    	curl_close($ch);
    	return $content;
    }

    // Website Custom Post Type
    function website_init() {
    // set up product labels
    $labels = array(
        'name' => 'Websites',
        'singular_name' => 'Website',
        'add_new' => 'Add New Website',
        'add_new_item' => 'Add New Website',
        'edit_item' => 'Edit Website',
        'new_item' => 'New Website',
        'all_items' => 'All Website',
        'view_item' => 'View Website',
        'search_items' => 'Search Website',
        'not_found' =>  'No Website Found',
        'not_found_in_trash' => 'No Website found in Trash', 
        'parent_item_colon' => '',
        'menu_name' => 'Websites',
    );
    
    // register post type
    $args = array(
        'labels' => $labels,
        'public' => true,
        'has_archive' => true,
        'show_ui' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'rewrite' => array('slug' => 'website'),
        'query_var' => true,
        'menu_icon' => 'dashicons-admin-multisite',
        'supports' => array(
            'title',
            'editor',
        ),

        'register_meta_box_cb' => 'global_notice_meta_box'
    );
    register_post_type( 'website', $args );
   
}

add_action( 'init', 'website_init' );

// Add MetaBox
function global_notice_meta_box() {

    add_meta_box(
        'cpt_meta',
        __( 'Fetched Source Code', 'sitepoint' ),
        'cpt_meta_box_callback'
    );

}

// Metabox Callback 

function cpt_meta_box_callback( $post ) {

    // Add a nonce field so we can check for it later.
    wp_nonce_field( 'cpt_meta_nonce', 'cpt_meta_nonce' );
    $value = get_post_meta( $post->ID, '_cpt_meta', true );
    $content=fetch_code( $post->post_content );
    echo "<textarea style='width:100%'>$content</textarea>";
}

// before post

function cpt_meta_before_post( $content ) {

    global $post;
    // retrieve the global notice for the current post
    $cpt_meta = esc_attr( get_post_meta( $post->ID, '_cpt_meta', true ) );
    $notice = "<div class='sp_cpt_meta'>$cpt_meta</div>";
    return $notice . $content;

}

add_filter( 'the_content', 'cpt_meta_before_post' );

// Action call for removing box
add_action( 'admin_menu', 'wpdocs_remove_publish_box' );

// Remove the Publish box
function wpdocs_remove_publish_box()
{
	remove_meta_box( 'submitdiv', 'website', 'side' );
	remove_meta_box( 'ef_editorial_meta', 'website', 'side' );
	remove_meta_box( 'authordiv' , 'website' , 'normal' ); 
	remove_meta_box( 'postcustom', 'website', 'normal' );
}

//Contact form
function cpt_form_code() {
	echo '<form action="' . '" method="post">';
	echo '<p>';
	echo 'Your Name (required) <br/>';
	echo '<input type="text" name="cpt-name" pattern="[a-zA-Z0-9 ]+" value="' . ( isset( $_POST["cpt-name"] ) ? esc_attr( $_POST["cpt-name"] ) : '' ) . '" size="40" />';
	echo '</p>';

	echo '<p>';
	echo 'Your Website URL (required) <br/>';
    echo '<input type="text" name="cpt-website"+"value="' . ( isset( $_POST['cpt-website']) ? esc_attr( $_POST["cpt-website"] ) : '' ) . '" size="40" />';
    echo '</p>';

	echo '<p><input type="submit" name="cpt-submitted" value="Send"/></p>';
	echo '</form>';

}

function validate_values() {
	global $reg_errors;
	$reg_errors = new WP_Error;

	// if the submit button is clicked, send the email
	if ( isset( $_POST['cpt-submitted'] ) ) {

		// sanitize form values
		$name    = sanitize_text_field( $_POST["cpt-name"] );
		$website    =   esc_url( $_POST['cpt-website'] );

        // Create post object
        $my_post = array(
        'post_title'    => wp_strip_all_tags( $_POST['cpt-name'] ),
        'post_content'  => $_POST['cpt-website'],
        'post_status'   => 'publish',
        'post_type' => 'website',
                 );

		// if required must not be left out
		if ( empty( $name ) || empty($website) ) 
		{
 	   $reg_errors->add('field', 'Required form field is missing');
 		}

		//if the website field is filled
 		elseif ( ! empty( $website ) ) {
		    if (! filter_var( $website, FILTER_VALIDATE_URL ) )
		     {
	        $reg_errors->add( 'Website', 'Website is not a valid URL' );
	    	} 
	    	else{
			$reg_errors =null;
			}

		} 
		if ( is_wp_error( $reg_errors) )  {
		    foreach ( $reg_errors->get_error_messages() as $error ) {
		     
		        echo '<div>';
		        echo '<strong>ERROR</strong>:';
		        echo $error . '<br/>';
		        echo '</div>';
		         
		    		}
 
		} 
			else {
					echo '<div>';
					echo '<p>Thanks for sharing this info. </p>';
					echo '</div>';

                    // Insert the post into the database
                    wp_insert_post( $my_post );

                    //Fetch Code 
					fetch_code($website );
			}
		
	}

}

function cf_shortcode() {
	ob_start();
	cpt_form_code();
	validate_values();
	return ob_get_clean();
}

add_shortcode( 'cpt_contact_form', 'cf_shortcode' );
